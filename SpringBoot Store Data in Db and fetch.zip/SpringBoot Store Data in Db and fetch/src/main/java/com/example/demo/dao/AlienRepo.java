package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Alien;

// In arguments mention class name and type of PrimaryKey 
public interface AlienRepo extends CrudRepository<Alien, Integer> {
	
}
