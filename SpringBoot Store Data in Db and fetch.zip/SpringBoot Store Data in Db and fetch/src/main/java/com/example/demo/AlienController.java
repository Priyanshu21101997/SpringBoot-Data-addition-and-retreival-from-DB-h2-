package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.AlienRepo;
import com.example.demo.model.Alien;

@Controller
public class AlienController {
	
	@Autowired
	AlienRepo repo; // Automatically we will get an object of AlienRepo
	
	@RequestMapping("/")
	public String home() {
		
		return "home.jsp";
	}
	
	@RequestMapping("/addAlien")
	public String addAlien(Alien alien) {
		
		
		repo.save(alien);
		return "home.jsp";
	}
	
	@RequestMapping("/fetchAlien")
	public ModelAndView fetchAlien(@RequestParam int aid) {
		
		Alien alien = repo.findById(aid).orElse(new Alien()); // If id is not found in database then we should returns a dummy object
		ModelAndView mv = new ModelAndView("showAlien.jsp"); // We can pass view(.jsp) in constructor as well
		mv.addObject(alien);
		return mv;
	}
}
